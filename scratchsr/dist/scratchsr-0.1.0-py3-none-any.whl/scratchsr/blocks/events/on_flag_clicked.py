from scratchsr.core.block import build_block

build_block({
    "opcode": "event_whenflagclicked",
})

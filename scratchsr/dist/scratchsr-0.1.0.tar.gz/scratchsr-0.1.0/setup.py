# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['scratchsr',
 'scratchsr.blocks',
 'scratchsr.blocks.events',
 'scratchsr.blocks.looks',
 'scratchsr.compiler',
 'scratchsr.compiler.blocks',
 'scratchsr.compiler.costumes',
 'scratchsr.compiler.packaging',
 'scratchsr.core',
 'scratchsr.decorators',
 'scratchsr.errors',
 'scratchsr.util']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['scsr = bin/scsr.py']}

setup_kwargs = {
    'name': 'scratchsr',
    'version': '0.1.0',
    'description': 'A Python framework for writing big Scratch programs',
    'long_description': None,
    'author': 'Olivier Audet-Yang',
    'author_email': '66892647+greentext01@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
